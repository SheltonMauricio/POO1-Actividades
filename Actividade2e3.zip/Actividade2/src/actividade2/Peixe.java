package actividade2;

import java.io.Serializable;

public class Peixe extends Animal implements Serializable {
    private String caract;

    public Peixe(String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
    }

    
    
    public Peixe(String caract, String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
        this.caract = caract;
    }

    @Override
    public String toString() {
        return "Peixe{" + "nome=" + nome + ", ambientes=" + ambiente + ", patas=" + patas + ", cor=" + cor + "caract=" + caract + "}\n";
    }  
}
