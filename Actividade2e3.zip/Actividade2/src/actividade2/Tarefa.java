package actividade2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class Tarefa {
    private File fl;
    private Peixe peixe;
    private Mamifero mamifero;
    private Validacao validacao;
    private int op;
    private int sair;
    
    public Tarefa() throws IOException {
        do{
            validacao = new Validacao();
            fl = new File("Animais.txt");
            op = validacao.validarInt(1, 3, """
                                            1. Registrar Peixe
                                            2. Registrar Mamifero
                                            3. Visualizar Animais registrados""");
            switch(op){
                case 1: registrarPeixe(); break;
                case 2: registrarMamifero(); break;
                case 3: visualizarAnimal(); break;
            }
            sair = validacao.validarInt(0, 1,"""
                                             Pretende efetuar mais alguma operacao? Digite:
                                             1. Se sim
                                             0. Pra sair""");
        }while(sair==1);
    }
    
    public void registrarPeixe() throws IOException{
        String nome = validacao.validarString(2, 15,"Insira o nome do peixe");
        String ambiente = "Aquatico";
        int patas = 0;
        String cor = validacao.validarString(4, 20, "Insira a cor do peixe");
        String caract = validacao.validarString(4, 45, "Quais as caracteristicas do tal peixe");
        
        peixe = new Peixe(caract, nome, ambiente, patas, cor);
        
        try {
            FileWriter fr = new FileWriter (fl, true);
            BufferedWriter bw = new BufferedWriter (fr);
            fr.write(peixe.toString());
            fr.close();
            System.out.println("Peixe Registrado com sucesso!");
            
        } catch (IOException e) {
            System.out.println("Ocorreu um erro:"+e);
        }    
    }
    
    public void registrarMamifero() throws IOException {
        String nome = validacao.validarString(2, 15,"Insira o nome do Mamifero");
        String ambiente = validacao.validarString(5, 15, "Qual o ambiente do Mamifero");
        int patas = validacao.validarInt(0, 4, "Digite o nr de patas do mamifero");
        String cor = validacao.validarString(4, 20, "Insira a cor do Mamifero");
        mamifero = new Mamifero(nome, ambiente, patas, cor);
        
        try {
            FileWriter fr = new FileWriter (fl, true);
            BufferedWriter bw = new BufferedWriter (fr);
            fr.write(mamifero.toString());
            fr.close();
            System.out.println("Mamifero registrado com sucesso!");
            
        } catch (IOException e) {
            System.out.println("Ocorreu um erro:"+e);
        }   
    }
    
       
    public void visualizarAnimal() throws IOException {
        String linha = "";
        try {
            FileReader fr = new FileReader(fl);
            BufferedReader br = new BufferedReader(fr);
            
            linha = br.readLine();
            
            while (linha!=null){
                System.out.println(linha);
                linha = br.readLine();   
            }
            
            br.close();
        } catch (FileNotFoundException ee){
            System.out.println("Ficheiro nao encontrado:"+ee);
        } catch (IOException pp){
            System.out.println("Problemas na leitura do ficheiro!"+pp);
        }
    }

}
