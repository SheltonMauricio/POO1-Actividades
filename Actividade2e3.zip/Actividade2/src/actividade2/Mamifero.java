package actividade2;

import java.io.Serializable;

public class Mamifero extends Animal implements Serializable {
    

    public Mamifero(String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
    }

    @Override
    public String toString() {
        return "Mamifero{" + "nome=" + nome + ", ambientes=" + ambiente + ", patas=" + patas + ", cor=" + cor + "}\n";
    }
}
