package actividade2;

import java.io.IOException;

public class Actividade2 {
    public static void main(String[] args) throws IOException {
        Tarefa tarefa = new Tarefa();
    }
    
}
