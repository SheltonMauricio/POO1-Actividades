package atividade3;
public class Ave extends Animal {
    protected String capacidadeVoo;
    
    public Ave(String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
    }
}
