package atividade3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Validacao {
    private BufferedReader x;
    public Validacao(){
        x= new BufferedReader(new InputStreamReader(System.in));
        
    }
    
    public int validarInt(int min, int max, String msg)throws IOException{
        int resposta;
        System.out.println(msg);
        do{
            try{
            resposta=Integer.parseInt(x.readLine());
            if(resposta<min || resposta>max)
            System.out.println("Valor incorreto! Tente novamente");
        }
            catch(NumberFormatException n){
                System.out.println("Valor invalido! Tente denovo");
                resposta=min-1;
            }
        }while(resposta<min || resposta>max);     
        
        return resposta;
    }
    
    public String validarString(int min,int max,String msg) throws IOException{
        String resposta;
        System.out.println(msg);
        do{
            resposta=x.readLine();
            if(resposta.trim().isEmpty() || resposta.length()<min || resposta.length()>max){
                System.out.println("Introduza novamente");
            }
        }while(resposta.trim().isEmpty() || resposta.length()<min || resposta.length()>max);
        
        return resposta;
    }   
}
