package atividade3;

import java.io.Serializable;

public class Cachorro extends Mamifero implements Serializable {
    private String raca;

    public Cachorro(String raca, int nrDentes, String nome, String ambiente, int patas, String cor) {
        super(nrDentes, nome, ambiente, patas, cor);
        this.raca = raca;
    }

    @Override
    public String toString() {
        return "Cachorro{" + "raca=" + raca + '}';
    }
    
}
