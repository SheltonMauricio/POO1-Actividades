package atividade3;

import java.io.Serializable;

public class BeijaFlor extends Ave implements Serializable {

    public BeijaFlor(String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
    }

    @Override
    public String toString() {
        return "BeijaFlor{" + '}';
    }
}
