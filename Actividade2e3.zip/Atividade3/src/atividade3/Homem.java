package atividade3;

import java.io.Serializable;

public class Homem extends Mamifero implements Serializable {
    private String classeSocial;

    public Homem(String classeSocial, int nrDentes, String nome, String ambiente, int patas, String cor) {
        super(nrDentes, nome, ambiente, patas, cor);
        this.classeSocial = classeSocial;
    }

    @Override
    public String toString() {
        return "Homem{" + "classeSocial=" + classeSocial + '}';
    }
}
