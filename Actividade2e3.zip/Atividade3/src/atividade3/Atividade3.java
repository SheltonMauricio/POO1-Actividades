package atividade3;

import java.io.IOException;

public class Atividade3 {
    public static void main(String[] args) throws IOException {
        Tarefa tarefa = new Tarefa(); 
    }
    
}
