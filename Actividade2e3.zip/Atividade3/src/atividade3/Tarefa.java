package atividade3;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class Tarefa {
    private BeijaFlor beijaFlor;
    private Homem homem;
    private Cachorro cachorro;
    private Validacao validacao;
    private File fl;
    private int op;
    private int sair;
    
    public Tarefa() throws IOException {
        do{
            validacao = new Validacao();
            fl = new File("Actividade3.dat");
            op = validacao.validarInt(1, 4, """
                                            1. Registrar Beija-Flor
                                            2. Registrar Homem
                                            3. Registrar Cachorro
                                            4. Visualizar Animais""");
            switch(op){
                case 1: registrarBeijaFlor(); break;
                case 2: registrarHomem(); break;
                case 3: registrarCachorro(); break;
                case 4: visualizarAnimais(); break;
            }
            sair = validacao.validarInt(0, 1,"""
                                             Pretende efetuar mais alguma operacao? Digite:
                                             1. Se sim
                                             0. Pra sair""");
        }while(sair==1);
    }
    
    public void registrarBeijaFlor() throws IOException {
        String nome = "Beija-Flor";
        String ambiente = "Aerio e  terrestre";
        int patas=2;
        String cor = validacao.validarString(4, 15, "Qual a cor do beija-flor");
        
        beijaFlor = new BeijaFlor(nome, ambiente, patas, cor);
        
        try {
            FileOutputStream fout = new FileOutputStream (fl, true);
            ObjectOutputStream obout = new ObjectOutputStream (fout);
            obout.writeObject(beijaFlor);
            obout.close();
            System.out.println("Registrado com sucesso!");
            
        } catch (IOException e) {
            System.out.println("Ocorreu um erro:"+e);
        } 
        
    }
    
    public void registrarHomem() throws IOException {
        String nome = validacao.validarString(2, 15,"Insira o nome");
        String ambiente = validacao.validarString(5, 15, "Qual o ambiente do Mamifero");
        int patas = 0;
        String cor = validacao.validarString(4, 20, "Insira a cor de pele");
        String classeSocial = validacao.validarString(4, 15, "Qual a classe social");
        int nrDentes = validacao.validarInt(0, 32, "Insira a quantidade de dentes ");
        
        homem = new Homem(classeSocial, nrDentes, nome, ambiente, patas, cor);
        
        try {
            FileOutputStream fout = new FileOutputStream (fl, true);
            ObjectOutputStream obout = new ObjectOutputStream (fout);
            obout.writeObject(homem);
            obout.close();
            System.out.println("Registrado com sucesso!");
            
        } catch (IOException e) {
            System.out.println("Ocorreu um erro:"+e);
        }
        
    }
    
    public void registrarCachorro() throws IOException {
        String nome = validacao.validarString(2, 15,"Insira o nome");
        String ambiente = validacao.validarString(5, 15, "Qual o ambiente do Mamifero");
        int patas = 0;
        String cor = validacao.validarString(4, 20, "Insira a cor de pele");
        int nrDentes = validacao.validarInt(0, 32, "Insira a quantidade de dentes ");
        String raca = validacao.validarString(4, 15, "Qual a raca do cachorro");
        
        cachorro = new Cachorro(raca, nrDentes, nome, ambiente, patas, cor);
        
        try {
            FileOutputStream fout = new FileOutputStream (fl, true);
            ObjectOutputStream obout = new ObjectOutputStream (fout);
            obout.writeObject(cachorro);
            obout.close();
            System.out.println("Registrado com sucesso!");
            
        } catch (IOException e) {
            System.out.println("Ocorreu um erro:"+e);
        }
    }
    
    public void visualizarAnimais(){
        try {
            FileInputStream fin= new FileInputStream (fl);
            ObjectInputStream obin = new ObjectInputStream (fin);
      
            cachorro = (Cachorro) obin.readObject();
            System.out.println("Objeto peixe lido do ficheiro: " + cachorro.toString());
            beijaFlor = (BeijaFlor) obin.readObject();
            System.out.println("Objeto mamifero lido do ficheiro: " + beijaFlor.toString());
            homem = (Homem) obin.readObject();
            System.out.println("Objeto mamifero lido do ficheiro: " + homem.toString());
            
            obin.close();
        } catch (FileNotFoundException ee){
            System.out.println("Ficheiro nao encontrado!");
        } catch (ClassNotFoundException eee){
            System.out.println("Verifique a existencia da classe Revista!!!");
        } catch (IOException pp){
            System.out.println("Problemas na leitura do ficheiro!");
        }
    }
}
