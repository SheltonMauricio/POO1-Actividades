package atividade3;
public class Mamifero extends Animal {
    protected int nrDentes;

    public Mamifero(int nrDentes, String nome, String ambiente, int patas, String cor) {
        super(nome, ambiente, patas, cor);
        this.nrDentes = nrDentes;
    }
    
}
